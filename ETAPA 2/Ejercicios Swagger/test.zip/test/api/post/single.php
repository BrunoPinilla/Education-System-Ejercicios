<?php
include('../includes/header.php');

Use Models\Post;

$post = new Post($db);

if(isset($_GET['id']))
{
    $post = $post->read_single_post($_GET['id'] ?? 11);

    if($post->rowCount())
    {
            // Have Posts
            $posts = [];

            // re-arrange data.

            while($row = $post->fetch(PDO::FETCH_OBJ))
            {
                $posts[$row->id] = [
                    'id' => $row->id,
                    'categoryName' => $row->category,
                    'title' => $row->title,
                    'description' => $row->description,
                    'created_at' => $row->created_at,
                ];
            }
            echo json_encode($posts);
    }
    else
    {
    echo json_encode(['message'=>'No Data']);
    }

    return $post;
}


