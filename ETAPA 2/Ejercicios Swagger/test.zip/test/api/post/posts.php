<?php
include('../includes/header.php');

Use Models\Post;

$post = new Post($db);
$data = $post->read();


if($data->rowCount())
{
    // Have Posts
    $posts = [];

    // re-arrange data.

    while($row = $data->fetch(PDO::FETCH_OBJ))
    {
        $posts[$row->id] = [
            'id' => $row->id,
            'categoryName' => $row->category,
            'title' => $row->title,
            'description' => $row->description,
            'created_at' => $row->created_at,
        ];
    }
    echo json_encode($posts);
}
else
{
    echo json_encode(['message'=>'No Data']);
}