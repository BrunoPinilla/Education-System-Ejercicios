<?php
include('../includes/header.php');

Use Models\Post;

$post = new Post($db);

// Get raw posted data.
// For $data to work -> add headers and in postman add content type.
$data = json_decode(file_get_contents("php://input"));

if(count($_POST))
{
    $params = [
        'id' =>  $_POST['id'],
        'title' => $_POST['title'],
        'description' => $_POST['description'],
        'category_id' => $_POST['category_id'],
    ];
    
    if($post->update_new_record($params))
    {
        echo json_encode(array('message' => 'Post updated'));
    }
}
else if(isset($data))
{
    $params = [
        'title' => $data->title,
        'description' => $data->description,
        'category_id' => $data->category_id,
        'id' => $data->id,
    ];
    
    if($post->update_new_record($params))
    {
        echo json_encode(array('message' => 'Post updated'));
    }
}