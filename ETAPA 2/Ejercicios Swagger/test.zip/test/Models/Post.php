<?php

namespace Models;

class Post {

    // Database data.
    private $connection;
    private $table = 'posts';

    // Post Properties
    public $id;
    public $category_id;
    public $title;
    public $description;
    public $created_at;

    public function __construct($db)
    {
        $this->connection = $db; 
    }

    
    public function read()
    {
        // Query to get posts data.

        $query = 'SELECT 
            category.name as category,
            posts.id,
            posts.title,
            posts.description,
            posts.category_id,
            posts.created_at
            FROM
            '.$this->table.' posts LEFT JOIN
            category 
            ON posts.category_id 
            ORDER BY
             posts.created_at DESC';

        $post = $this->connection->prepare($query);
        
        $post->execute();

        return $post;
    }


    public function read_single_post($id)
    {
        $this->id = $id;
        // Query to get posts data.
        
        $query = 'SELECT 
            category.name as category,
            posts.id,
            posts.category_id,
            posts.title,
            posts.description,
            posts.created_at
            FROM
            '.$this->table.' posts LEFT JOIN
            category 
            ON posts.category_id = category.id
            WHERE posts.id= ?
            LIMIT 0,1';
            
        $post = $this->connection->prepare($query);
        
        //$post->bindParam(9, $this->id);
        
        $post->execute([$this->id]);

        return $post;
       
    }


    public function create_new_record($params)
    {
        try
        {
            $this->title       = $params['title'];
            $this->description = $params['description'];
            $this->category_id = $params['category_id'];
    
            $query = 'INSERT INTO '. $this->table .' 
                SET
                  title = :title,
                  category_id = :category_id,
                  description = :details';
           
            $statement = $this->connection->prepare($query);
                    
            $statement->bindValue('title', $this->title);
            $statement->bindValue('category_id', $this->category_id);
            $statement->bindValue('details', $this->description);
            
            if($statement->execute())
            {
                return true;
            }
    
            return false;
        }
        catch(PDOException $e)
        {
            echo $e->getMessage();
        }
    }


    public function update_new_record($params)
    {
        try
        {
            $this->id          = $params['id'];
            $this->title       = $params['title'];
            $this->description = $params['description'];
            $this->category_id = $params['category_id'];
    
            $query = 'UPDATE '. $this->table .' 
                SET
                  title = :title,
                  category_id = :category_id,
                  description = :details
                WHERE id = :id';
           
            $statement = $this->connection->prepare($query);
            
            $statement->bindValue('id', $this->id);
            $statement->bindValue('title', $this->title);
            $statement->bindValue('category_id', $this->category_id);
            $statement->bindValue('details', $this->description);
            
            if($statement->execute())
            {
                return true;
            }
    
            return false;
        }
        catch(PDOException $e)
        {
            echo $e->getMessage();
        }
    }


    public function destroy_post($id)
    {
        try
        {
              // Assigning values.

              $this->id = $id;

              // Query for updating existing record.

              $query = 'DELETE FROM '.$this->table.' 
                   WHERE id = :id';

              $post = $this->connection->prepare($query);

              $post->bindValue('id', $this->id);
              
              if($post->execute())
              {
                  return true;
              }

              return false;
        }
        catch(PDOException $e)
        {
            echo $e->getMessage();
        }
    }
}